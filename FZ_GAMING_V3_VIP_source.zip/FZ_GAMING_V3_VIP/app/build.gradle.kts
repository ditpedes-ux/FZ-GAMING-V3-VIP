plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fzgaming.v3"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fzgaming.v3"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "3.0"
    }
}
