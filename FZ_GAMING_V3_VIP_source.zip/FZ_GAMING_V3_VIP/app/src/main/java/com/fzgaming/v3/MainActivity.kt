package com.fzgaming.v3

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fz_profile", MODE_PRIVATE) }
    private val red = Color.rgb(255, 48, 48)
    private val bg = Color.rgb(12, 12, 12)
    private val panel = Color.rgb(28, 28, 28)
    private val white = Color.WHITE
    private lateinit var status: TextView
    private val bars = mutableMapOf<String, SeekBar>()
    private val values = linkedMapOf(
        "General" to 95, "Red Dot" to 90, "2x Scope" to 85,
        "4x Scope" to 80, "Sniper" to 50, "Free Look" to 75
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun showDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("FZ GAMING", 30, red, true))
        page.addView(label("V3 VIP  •  ANDROID GAMING COMPANION", 12, white, true))
        page.addView(space(16))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(panel)
        }
        card.addView(label("SYSTEM PROFILE", 14, red, true))
        card.addView(label("Preset lokal • Tidak perlu root • Offline", 13, white, false))
        status = label("Status: " + prefs.getString("profile", "DEFAULT"), 14, white, true)
        card.addView(status)
        page.addView(card)
        page.addView(space(18))
        page.addView(label("SENSITIVITY PRESET", 18, red, true))
        page.addView(label("Nilai ini adalah rekomendasi yang bisa lu sesuaikan di dalam game.", 12, white, false))

        values.forEach { (name, defaultValue) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(panel)
            }
            val saved = prefs.getInt(name, defaultValue)
            val title = TextView(this).apply {
                text = "$name: $saved"
                setTextColor(white); textSize = 14f
            }
            val seek = SeekBar(this).apply {
                max = 100
                progress = saved
                progressTintList = android.content.res.ColorStateList.valueOf(red)
                thumbTintList = android.content.res.ColorStateList.valueOf(red)
            }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    title.text = "$name: $progress"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            bars[name] = seek
            row.addView(title); row.addView(seek)
            page.addView(row)
            page.addView(space(7))
        }

        page.addView(actionButton("SIMPAN PRESET", red) { savePreset() })
        page.addView(space(8))
        page.addView(actionButton("RESET KE DEFAULT", Color.DKGRAY) { resetPreset() })
        page.addView(space(18))
        page.addView(label("ANDROID SETTINGS", 18, red, true))
        page.addView(actionButton("BUKA PENGATURAN LAYAR", panel) {
            openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        })
        page.addView(space(8))
        page.addView(actionButton("BUKA PENGATURAN BATERAI", panel) {
            openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        })
        page.addView(space(16))
        page.addView(label("FPS STABILITY HELPER", 18, red, true))
        page.addView(label("Tips aman: tutup aplikasi yang tidak dipakai, aktifkan mode performa/game jika tersedia, jaga suhu HP, dan gunakan pengaturan grafis yang stabil. Aplikasi ini tidak mengubah FPS game secara paksa.", 13, white, false))
        page.addView(space(16))
        page.addView(label("Catatan: preset hanya tersimpan di aplikasi. Untuk menerapkannya, masukkan nilainya secara manual di pengaturan sensitivitas Free Fire. Tidak ada aim-lock, auto-headshot, bypass, atau modifikasi file game.", 12, Color.LTGRAY, false))
    }

    private fun savePreset() {
        val editor = prefs.edit()
        bars.forEach { (name, seek) -> editor.putInt(name, seek.progress) }
        editor.putString("profile", "CUSTOM SAVED").apply()
        status.text = "Status: CUSTOM SAVED ✓"
        Toast.makeText(this, "Preset berhasil disimpan", Toast.LENGTH_SHORT).show()
    }

    private fun resetPreset() {
        prefs.edit().clear().putString("profile", "DEFAULT").apply()
        Toast.makeText(this, "Preset dikembalikan ke default", Toast.LENGTH_SHORT).show()
        showDashboard()
    }

    private fun openSettings(intent: Intent) {
        try { startActivity(intent) }
        catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(color)
            isAllCaps = false
            textSize = 14f
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            )
        }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun space(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
