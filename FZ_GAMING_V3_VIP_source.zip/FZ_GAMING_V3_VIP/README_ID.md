# FZ GAMING V3 VIP

Proyek Android Native (Kotlin), bukan HTML/PWA.

## Fitur yang tersedia
- Dashboard offline bertema hitam-merah.
- Slider preset sensitivitas Free Fire.
- Simpan preset lokal menggunakan SharedPreferences.
- Reset konfigurasi ke default.
- Pintasan ke pengaturan layar dan baterai Android.
- Tips stabilitas FPS yang aman.

## Batasan
Aplikasi ini tidak mengubah FPS game secara paksa, tidak mengubah sensitivitas internal Free Fire, dan tidak menyediakan auto-headshot/aim-lock. Nilai sensitivitas harus diterapkan manual di dalam game.

## Build
Perlu Android Studio atau layanan build Android yang mendukung Gradle:
- JDK 17
- Android SDK Platform 35
- Gradle/Android Gradle Plugin sesuai konfigurasi

Buka folder proyek ini sebagai proyek Gradle, tunggu sinkronisasi, lalu jalankan `assembleDebug`.
APK debug akan dibuat di:
`app/build/outputs/apk/debug/app-debug.apk`

APK belum dikompilasi atau ditandatangani dalam paket source ini.
